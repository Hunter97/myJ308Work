/**
 *  Java 90_303
 *  Paul Wallace
 *  Assignment 2 - PaulWallace_Java303: FileIO.java
 *  
 *  Super class for the FileIO_Handler utility.  Implements interface IFileIO.  
 *  Utility is an abstract Java File Class that provides the user with a secure
 *  means to read and write data to and from files. 
 *  
 *  The Class provides the user with methods to:
 *      *   Validates the existence and path of a target folder within a directory path
 *      *   Validates the target folder contains files with the specified extension/s 
 *      *   Insures the files, within target folder, are readable and/or writable
 *      *   Will create a file to be written too, if target file does not exist
 *      *   Reads data from a valid file and writes data to a valid file
 *      *   File paths supported are absolute and relative
 *  
 *  Throws:     IOExceptions
 *  Catches:    Security Exceptions and abstract FileReadWriteExceptions          
 *  
 */
package PaulWallace_Jave303;
import java.io.File;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;

/**
 * @author Paul Wallace
 *
 */
public abstract class FileIO implements IFileIO {

    /**
     *  Failed to create a File object for read class.
     *  Initialized to true.
     */
    public boolean m_fileObjReadFail = true;
    /**
     *  File object for writing is null
     */
    public boolean m_fileObjWriteFailed = true;

    /**
     *  File not writable
     */
    //public boolean m_isWritable;

    
    /**
     *  Default constructor file FileIO class
     */
    public FileIO() {
    }
    
    
    /**
    * Tests a file to insure it exists, is readable, can execute, is not
    * hidden, and is a file.  If one of the conditions fail, the method
    * throws a FileReadWriteException.
    *
    * @param    FileIO object provides path to file
    * @return   True if meets all conditions, FileReadWriteException if false.
    * @throws   IOException, SecurityException, and a FileReadWriteException
    */
    public boolean isFileReadable( File file ) throws SecurityException, FileReadWriteException, IOException {

        //File file = new File( m_fileDirRead.getParent().toString(), m_fileDirRead.getName() );
        
        if( !file.canRead() || !file.canExecute() || file.isHidden() || !file.isFile() ) {
            throw new FileReadWriteException();
        }

        return true;
    }


    /**
    * Tests a file to insure it is writable, is not hidden, and can execute.
    * If one of the condition fails, the method throws a FileReadWriteExcep-
    * tion.
    * 
    * @param    FileIO object provides a path to file
    * @return   True if meets all conditions, FileReadWriteException if false.
    * @throws   IOException, SecurityException, and a FileReadWriteException.
    */
    public boolean isFileWritable( File file ) throws SecurityException, FileReadWriteException, IOException {

        if( !file.canWrite() || file.isHidden() || !file.canExecute() ) {
            throw new FileReadWriteException();
        }

        return true;
    }
    
    
    /**
     * Verifies that the argument file exists, otherwise creates a new file.
     * The method accepts a path/file string, either an absolute path or a
     * relative path.
     * 
     * @param   filename - String path to file, absolute or relative.
     * @return  True if the file exists or a new file was created, false if
     *          both tests failed.
     * @throws  IOException
     */
    public boolean hasFileToWrite( String filename ) throws IOException {

        File file = new File( filename );
        boolean fileCreated = false;

        if( file.exists() ) {
            fileCreated = true;
        } else {
            if( file.createNewFile() ) {
                fileCreated = true;
            }
        }

        return fileCreated;
    }
    
    
    /**
     * Tests whether directory, denoted by Path argument, is a valid directory.
     * The directory can accept an absolute or relative path.
     * 
     * @param path  Directory path to file, absolute or relative.
     * @return      True if a valid directory.
     */
    public boolean isValidDirectory( Path path ) {

        File file = new File( path.toAbsolutePath().getParent().toString() );
        boolean isValid = false;

        if ( file.isDirectory() ) {
            isValid = true;
        } else {
            System.out.println( "ERROR(FileIO) isValidDirectory: DIRECTORY " + path + " IS AN INVALID PATH.");
        }

        return isValid;
    }


    /**
     * Searches the folder, denoted by the Path argument, for the existence of
     * a single file that meets the condition of the extension argument.
     * Returns true if a file is found that meets this condition.  The Path can
     * be an absolute or relative Path.
     * 
     * @param   path    Directory path, absolute or relative.
     * @param   extensions  File type to search for existence.
     * @return              True is directory contains one or more files.
     * @throws IOException
     */
    public boolean hasFiles( Path path, String extensions ) throws IOException {

        boolean hasFiles = false;
        File file;

        try ( DirectoryStream<Path> dirStream = Files.newDirectoryStream(path, extensions )) {
            for ( Path p : dirStream ) {
                file = new File( p.toString() );

                if ( file.exists() ) {
                    hasFiles = true;
                    break;
                }  
                System.out.println( file.toString() );
            }

            if( !hasFiles ) {
                System.out.println( "ERROR(FileIO) hasFiles: NO FILES FOUND IN DIRECTORY " + path.toAbsolutePath() + " WITH EXTENSION " + extensions );
            }
            return hasFiles;
        }
    }


    /**
     * Gets an ArrayList of all files with their absolute or relative path that
     * meets the file type provided as an argument.  Returns each path/file
     * element, one at time.
     * 
     * @param dirPath   Directory path, absolute or relative.   
     * @return          The next ArrayList element (file). 
     * @throws  IOException
     */
    public ArrayList<Path> getFileList( Path dirPath, String extensions ) throws IOException {

        ArrayList<Path> fileArrList = new ArrayList<>();

        try ( DirectoryStream<Path> dirStream = Files.newDirectoryStream( dirPath, extensions ) ) {

            for ( Path path : dirStream ) {
                fileArrList.add( path );
            }
            return fileArrList;
        }
    }


    @Override
    public abstract byte[] readBytes( File fileObj ) throws IOException;

    @Override
    public abstract File getFile( String filename ) throws IOException;

    @Override
    public abstract void writeBytes( File fileObj, byte[] byteStream) throws IOException;
}
