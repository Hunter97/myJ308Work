/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package pwall_helloWorld;

/**
 *
 * @author prwallace
 */
public class HelloWorld {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println( "Hello World" );
    }
}
